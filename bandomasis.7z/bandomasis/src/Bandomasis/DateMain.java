/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bandomasis;

import java.util.Scanner;

/**
 *
 * @author laurf
 */
public class DateMain {
    String input;
    String output;
    public DateMain()
    {
        Scanner in=new Scanner(System.in);
        System.out.println("Enter date in a following format: YYYY-MM-DD HH.mm.SS:sss");
        input=in.nextLine();
        output=convert(input);
        System.out.println(output);
    }
private String convert(String input)
{
    String [] block=input.split("[-.: ]+");
    output="Current time is "+block[3]+" hours, "+block[4]+" min, "+block[5]+" sec & "+block[6]+" millis. Date: "+block[2]+"/"+block[1]+"/"+block[0]+".";
    return output;
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        new DateMain();
    }
    
}
