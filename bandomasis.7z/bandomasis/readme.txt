Code is in src part. I don't know JavaScript just yet so I did the task in Java, on NetBeans IDE. 
In DateFrame file I have done GUI for the task, making it more flexible.
In DateMain it's mainly a simple back-end code.

Laurynas Lazauskas